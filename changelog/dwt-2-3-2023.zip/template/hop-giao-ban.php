<?php require_once($template_path.'header/header-master.php'); ?>
<!--index page start-->
<div class="pageWithSidebar">
    <?php require_once($template_path.'sidebar/sidebarMaster/sidebarLeft.php'); ?>
    <div id="mainWrap" class="mainWrap">
        <div class="mainSection">
            <div class="main">
                <div class="container-fluid">
                    <div class="mainSection_heading">
                        <h5 class="mainSection_heading-title">
                            Họp Giao Ban
                        </h5>
                        <div class="mainSection_heading-subtitle">Vui lòng hoàn thành trước 10h00 sáng hàng ngày</div>
                        
                        <div id="thismonth" class="mainSection_thismonth"></div>
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center pb-3">
                                        <div class="card-title">Tổng quan</div>
                                        
                                        <div class="main_search d-flex">
                                            Chọn ngày tháng
                                        </div>
                                    </div>
                                    <div class='row'>
                                        <div class="col-md-6">
                                            <div class="form-control">
                                                <div class="mt-3 mb-3 row">
                                                    <label for="days" class="col-sm-2 col-form-label"><i class="bi bi-calendar2"></i> Ngày</label>
                                                    <div class="col-sm-10">
                                                    <input type="text" placeholder="Nhập ngày tháng" class="form-control" id="days">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="timeStart" class="col-sm-2 col-form-label"><i class="bi bi-alarm"></i> Thời gian</label>
                                                    <div class="col-sm-5">
                                                        <input type="text" placeholder="Bắt đầu" class="form-control" id="timeStart">
                                                    </div>
                                                    <div class="col-sm-5">
                                                        <input type="text" placeholder="Kết thúc"  class="form-control" id="timeEnđ">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="timeStart" class="col-form-label"><i class="bi bi-file-earmark-text"></i> Mục tiêu cuộc họp</label>
                                                    <div class="col">
                                                        <textarea class="form-control" placeholder="Nhập nội dung cuộc họp"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-control p-4">
                                                <div class="mb-3 row">
                                                    <label for="staticEmail" class="col-form-label"><i class="bi bi-person-add"></i> Thành viên tham gia</label>
                                                    <select class="selectpicker" multiple data-actions-box="true"
                                                    data-width="100%" data-live-search="true">
                                                        <option>Thành viên 1</option>
                                                        <option>Thành viên 2</option>
                                                        <option>Thành viên 3</option>
                                                        <option>Thành viên 4</option>
                                                        <option>Thành viên 5</option>
                                                        <option>Thành viên 6</option>
                                                        <option>Thành viên 7</option>
                                                        <option>Thành viên 8</option>
                                                    </select>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="staticEmail" class="col-form-label"><i class="bi bi-person-dash"></i> Thành viên vắng</label>
                                                    <select class="selectpicker" multiple data-actions-box="true"
                                                    data-width="100%" data-live-search="true">
                                                        <option>Thành viên 1</option>
                                                        <option>Thành viên 2</option>
                                                        <option>Thành viên 3</option>
                                                        <option>Thành viên 4</option>
                                                        <option>Thành viên 5</option>
                                                        <option>Thành viên 6</option>
                                                        <option>Thành viên 7</option>
                                                        <option>Thành viên 8</option>
                                                    </select>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>

                            <div class="card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center pb-3">
                                        <div class="card-title">Nội dung chính</div>
                                        
                                        <div class="main_search d-flex">
                                            Ngày ghi biên bản
                                        </div>
                                    </div>
                                    <div class='row'>
                                        <div class="col-md-12">
                                            <div class="form-control">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                            <tr>
                                                            <th scope="col">TT</th>
                                                            <th scope="col">Đầu mục nhiệm vụ</th>
                                                            <th scope="col">Deadline</th>
                                                            <th scope="col">Báo cáo kết quả</th>
                                                            <th scope="col">Kế hoạch</th>
                                                            <th scope="col">Người phụ trách</th>
                                                            <th scope="col">Đề xuất cải thiện</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <th scope="row">1</th>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">2</th>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">3</th>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">4</th>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                            </tr>
                                                            <tr>
                                                                <th scope="row">5</th>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                                <td contenteditable="true">Lorem ipsum dolor</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    
                                                </div>
                                                <div class="action_table-wrapper text-end mb-3">
                                                    <a class="btn btn-outline-danger action_table-btn">
                                                        <i class="bi bi-airplane"></i>
                                                        Đến kho lưu trữ
                                                    </a>
                                                    <a href='bien-ban-hop' class="btn btn-danger action_table-btn">
                                                        <i class="bi bi-save"></i>
                                                        Duyệt & Lưu PPF
                                                    </a>
                                                </div>
                                                <div id='warning_notification' class="alert alert-warning alert-dismissible fade show border-left border-warning" role="alert">
                                                    <div class='d-flex align-items-center'>
                                                        <div><i class="bi bi-exclamation-triangle pe-2"></i></div>
                                                        <div>
                                                            <h3 class="alert-heading">
                                                                
                                                                Cảnh báo
                                                            </h3>
                                                            <p class='m-0'>Nhiệm vụ <strong>Họp giao ban </strong>ngày đã quá hạn!</p>
                                                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
            <div class="footer">
                <div class="container">Copyright © 2023 S-Team. All rights reserved.</div>
            </div>
        </div>
    </div>
    <?php require_once($template_path.'sidebar/sidebarMaster/sidebarRight.php'); ?>
</div>
<!--end index page-->
<?php require_once($template_path.'footer/footer-master.php'); ?>